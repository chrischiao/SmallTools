﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using ProtectService;

namespace KeyGenerator
{
    class Program
    {
        static void Main(string[] args)
        {
            string rsaPrivateKey;
            string rsaPublicKey;
            RSACryption.RSAKey(out rsaPrivateKey, out rsaPublicKey);

            string aesKey = AESCryption.InitAESKey();

            using (FileStream fs = new FileStream("key.txt", FileMode.Create))
            {
                using (StreamWriter sw = new StreamWriter(fs))
                {
                    sw.WriteLine("\r\nRSA Private Key:");
                    sw.WriteLine(rsaPrivateKey);
                    sw.WriteLine("\r\nRSA public Key:");
                    sw.WriteLine(rsaPublicKey);
                    sw.WriteLine("\r\nAES Key:");
                    sw.WriteLine(aesKey);

                    sw.Flush();
                    sw.Close();
                    fs.Close();
                }
            }

            Console.WriteLine("生成成功！");
            Console.ReadKey();
        }
    }
}
