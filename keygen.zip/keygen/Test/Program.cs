﻿using System;
using System.Management;
using System.IO;
using System.Security.Cryptography;
using System.Runtime.Serialization.Formatters.Binary;

namespace Test
{
    class Program
    {
        public static void Main()
        {
            Console.WriteLine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments));

            #region binaryformatter
            //var model = new RegistrationModel
            //{
            //    MAC = "94-DE-80-65-BF-CD",
            //    MotherBoardId = "unknown",
            //    ExpirationDate = DateTime.Now.ToBinary(),
            //    Company = "Epoint",
            //};

            //var bytes = ObjectToBytes(model);
            //var model2 = GetObject(bytes) as RegistrationModel;

            //Console.WriteLine(model2.MAC);
            #endregion

            //Console.WriteLine(GetMotherBoardID());

            #region BitConverter, HashAlgorithm

            //int len = 128;
            //int len2 = 5;
            //byte[] bytes1 = BitConverter.GetBytes(len);
            //byte[] bytes2 = BitConverter.GetBytes(len2);
            //byte[] bytes = bytes1.Concat(bytes2).ToArray();
            //int len3 = BitConverter.ToInt32(bytes, 0);
            //int len4 = BitConverter.ToInt32(bytes.Skip(4).ToArray(), 0);
            //Console.WriteLine(len3.ToString());
            //Console.WriteLine(len4.ToString());

            //HashAlgorithm md51 = HashAlgorithm.Create("MD5");
            //byte[] hashData1 = md51.ComputeHash(bytes1);
            //foreach (var i in hashData1)
            //    Console.Write(i);

            //Console.WriteLine();

            //HashAlgorithm md52 = HashAlgorithm.Create("MD5");
            //byte[] hashData2 = md52.ComputeHash(bytes1);
            //foreach (var i in hashData2)
            //    Console.Write(i);

            #endregion

            #region aes
            //string original = "Here is some data to encrypt!";

            //// Create a new instance of the Aes class.  This generates a new key and initialization vector (IV).
            //using (Aes myAes = Aes.Create())
            //{

            //    // Encrypt the string to an array of bytes.
            //    byte[] encrypted = EncryptStringToBytes_Aes(original, myAes.Key, myAes.IV);

            //    // Decrypt the bytes to a string.
            //    string roundtrip = DecryptStringFromBytes_Aes(encrypted, myAes.Key, myAes.IV);

            //    //Display the original data and the decrypted data.
            //    Console.WriteLine("Original:   {0}", original);
            //    Console.WriteLine("Round Trip: {0}", roundtrip);

            //    //AesExample.Test();
            //}
            #endregion

            Console.ReadKey();
        }

        /// <summary>
        /// 将byte[]数组转换为Object
        /// </summary>
        /// <param name="originalBytes"></param>
        /// <returns></returns>
        public static object GetObject(byte[] bytes)
        {
            using (var stream = new MemoryStream(bytes))
            {
                stream.Position = 0;
                var formatter = new BinaryFormatter();
                return formatter.Deserialize(stream);
            }
        }

        /// <summary>
        /// 将object转换为byte[]数组
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public static byte[] ObjectToBytes(object model)
        {
            using (var stream = new MemoryStream())
            {
                var formatter = new BinaryFormatter();
                formatter.Serialize(stream, model);
                var bytes = stream.GetBuffer();
                stream.Close();
                return bytes;
            }
        }

        public static string GetMotherBoardID()
        {
            try
            {
                ManagementClass mc = new ManagementClass("Win32_BaseBoard");
                ManagementObjectCollection moc = mc.GetInstances();
                string strID = null;
                foreach (ManagementObject mo in moc)
                {
                    strID = mo.Properties["SerialNumber"].Value.ToString();
                    break;
                }
                return strID;
            }
            catch
            {
                return "unknown";
            }
        }
    }
}