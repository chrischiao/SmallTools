﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Test
{
    [Serializable]
    public class RegistrationModel
    {
        public string MAC { get; set; }

        public string MotherBoardId { get; set; }

        public long ExpirationDate { get; set; }

        public string Company { get; set; }
    }
}
