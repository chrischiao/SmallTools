﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ProtectService
{
    public class CryptographyService
    {
        private const string AESKEY = "WNYz68HIePK3Es9CQQd4Zar4v0AI6wriXoociWxazMU=";
        private const int VERSION = 1;

        #region client

        private const string RSAPUBLICKEY = "<RSAKeyValue><Modulus>3Mr/6vyQ6f6W4PbJ4UmrfmBYXWOXAbwov9GDyntv5TDYsdI+7Tx+kA/7dNhiCfFaRSRmV85vzsGAJEDkRlBg6mlhdaX89Tt0T4zpul42Vm0J5K3hBCK+zhfU/SmdCZtjH4geRoovD8+l4KUQ8z30wlcZFaEqhDR5CeCU5+8ZCEU=</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>";

        /// <summary>
        /// 生成申请码
        /// </summary>
        public static string GenerateRequestCode()
        {
            // 版本信息
            byte[] version = BitConverter.GetBytes(VERSION);

            // 注册信息
            var registrationInfo = new RegistrationInfo
            {
                MAC = GetMacAddress(),
                MotherBoardId = GetMotherBoardID(),
            };
            byte[] data = BinarySerializer.ObjectToBytes(registrationInfo);
            byte[] pack = version.Concat(data).ToArray();

            // RSA公钥加密
            RSACryption rsa = new RSACryption();
            byte[] encryptBytes = rsa.Encrypt(RSAPUBLICKEY, pack);

            // Base64编码
            return Convert.ToBase64String(encryptBytes);
        }

        /// <summary>
        /// 验证授权
        /// </summary>
        public static bool VerifyAuthorization(string registrationCode, out string msg)
        {
            msg = "解码失败";
            if (!Base64Coder.FromBase64String(registrationCode, out byte[] fullData) || fullData.Length < 5)
                return false;

            int signatureLength = BitConverter.ToInt32(fullData, 0);
            if (fullData.Length < 5 + signatureLength)
                return false;

            byte[] signature = fullData.Skip(4).Take(signatureLength).ToArray();
            byte[] encryptData = fullData.Skip(4 + signatureLength).ToArray();

            // RSA公钥验证签名
            msg = "签名错误";
            RSACryption rsa = new RSACryption();
            byte[] hashData = rsa.GetHash(encryptData);
            if (!rsa.VerifySignature(RSAPUBLICKEY, hashData, signature))
                return false;

            // AES解密
            msg = "解密失败";
            AESCryption aes = new AESCryption();
            if (!aes.Decrypt(encryptData, AESKEY, out byte[] pack) || pack.Length < 5)
                return false;

            // 判断版本
            msg = "软件版本不匹配";
            int version = BitConverter.ToInt32(pack, 0);
            if (version != VERSION)
                return false;

            // 验证注册信息
            msg = "提取注册信息失败";
            try
            {
                byte[] data = pack.Skip(4).ToArray();
                RegistrationInfo registrationInfo = BinarySerializer.GetObject(data) as RegistrationInfo;
                return IslegalRegistration(registrationInfo, out msg);
            }
            catch
            {
                return false;
            }
        }

        public static bool IslegalRegistration(RegistrationInfo registrationInfo, out string msg)
        {
            msg = "已到期";
            DateTime expirationDate = DateTime.FromBinary(registrationInfo.ExpirationDate);
            if (expirationDate < DateTime.Now)
                return false;

            msg = "注册信息与本机信息不匹配";
            string mac = GetMacAddress();
            if (!string.Equals(mac, registrationInfo.MAC))
                return false;

            string boardId = GetMotherBoardID();
            if (!string.Equals(boardId, registrationInfo.MotherBoardId))
                return false;

            msg = "";
            return true;
        }

        public static void SaveAuthorization(string registrationCode)
        {
            if (!Base64Coder.FromBase64String(registrationCode, out byte[] data))
                return;

            string filePath = GetAuthorizationPath();
            if (File.Exists(filePath))
                File.Delete(filePath);

            using (FileStream fs = new FileStream(filePath, FileMode.Create))
            {
                // 保存成文本文件
                //using (StreamWriter sw = new StreamWriter(fs))
                //{
                //    sw.Write(registrationCode);
                //    sw.Flush();
                //    sw.Close();
                //    fs.Close();
                //}

                // 保存成二进制文件
                fs.Seek(0, SeekOrigin.Begin);
                fs.Write(data, 0, data.Length);
                fs.Flush();
                fs.Close();
            }
        }

        public static bool ReadAuthorization()
        {
            string filePath = GetAuthorizationPath();
            if (!File.Exists(filePath))
                return false;

            string registrationCode = string.Empty;
            using (FileStream fs = new FileStream(filePath, FileMode.Open))
            {
                // 读文本文件
                //using (StreamReader rw = new StreamReader(fs))
                //{
                //    registrationCode = rw.ReadToEnd();
                //    rw.Close();
                //    fs.Close();
                //}

                // 读二进制文件
                byte[] bytes = new byte[fs.Length];
                int numBytesToRead = (int)fs.Length;
                int numBytesRead = 0;
                while (numBytesToRead > 0)
                {
                    // Read may return anything from 0 to numBytesToRead.
                    int n = fs.Read(bytes, numBytesRead, numBytesToRead);
                    // Break when the end of the file is reached.
                    if (n == 0)
                        break;
                    numBytesRead += n;
                    numBytesToRead -= n;
                }
                registrationCode = Convert.ToBase64String(bytes);
            }

            return VerifyAuthorization(registrationCode, out string msg);
        }

        private static string GetAuthorizationPath()
        {
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Fashion.LK");
        }

        public static string GetMacAddress()
        {
            //try
            //{
            //    string mac = string.Empty;
            //    ManagementClass mc = new ManagementClass("Win32_NetworkAdapterConfiguration");
            //    ManagementObjectCollection moc = mc.GetInstances();
            //    foreach (ManagementObject mo in moc)
            //    {
            //        if ((bool)mo["IPEnabled"] == true)
            //        {
            //            mac = mo["MacAddress"].ToString();
            //        }
            //    }
            //    moc = null;
            //    mc = null;
            //    return mac;
            //}
            //catch
            //{
                return "unknown";
            //}
        }

        public static string GetMotherBoardID()
        {
            //try
            //{
            //    ManagementClass mc = new ManagementClass("Win32_BaseBoard");
            //    ManagementObjectCollection moc = mc.GetInstances();
            //    string id = null;
            //    foreach (ManagementObject mo in moc)
            //    {
            //        id = mo.Properties["SerialNumber"].Value.ToString();
            //        break;
            //    }
            //    return id;
            //}
            //catch
            //{
                return "unknown";
            //}
        }

        #endregion

        #region keygen

        private const string RSAPRIVATEKEY = "<RSAKeyValue><Modulus>3Mr/6vyQ6f6W4PbJ4UmrfmBYXWOXAbwov9GDyntv5TDYsdI+7Tx+kA/7dNhiCfFaRSRmV85vzsGAJEDkRlBg6mlhdaX89Tt0T4zpul42Vm0J5K3hBCK+zhfU/SmdCZtjH4geRoovD8+l4KUQ8z30wlcZFaEqhDR5CeCU5+8ZCEU=</Modulus><Exponent>AQAB</Exponent><P>+FLBKwADg7gy1y+Evj73ovKJE7+USGhxOUu399EOFmonA5oxd+uYp2oTj/SIbnp7VoENMjaiZYxXPmKjvMDb1w==</P><Q>455eYznRJO3iSa8N6wwfLOZx4+FVV41zhPKlBG27yqctdFv/+IDbyTC8u1icqBLRI5U6DzZJ6HT++taIHSSZQw==</Q><DP>nY176/llQXRkJW2Lzl0LJ4K0gCgkP9CsTcsB3STxyDzvpfR2AH0lbMr7wHFJAreJe7gDlGFfpghl7joNYxwGHw==</DP><DQ>FNFlPJoLIN+I9MhH85l2OHsTK45uacWMLTqsEQ2gQVas95l6fdX7RBlrCY9/NHgUHLcHSmDivZoFwBdi95djVQ==</DQ><InverseQ>SDw7Lx1ZYrwyIPzqJLTFYIqbYnFjSjJ4M9+yu8d+zBlBqhgGyV6jmxhXJWKwsEsa+jDMNAkUL0Ri/adOfRm8qg==</InverseQ><D>AlkiWaRwAh0UC7Z0NTIsYb6ykeOyQnF22Xtn9GpVqVFYrKN4ydsf2XZiDT8T49kuRZf6gqqOY9uI+lm6U8kdDrwaWsAL8je9e7+Uasqwyc9pKsMmcWG8s0ahpHh3DSR1JDy6wGayvCZJntXlkDa5EfbUxc8c3BW2ZjG8dwaess0=</D></RSAKeyValue>";

        /// <summary>
        /// 根据申请码生成注册码
        /// </summary>
        public static bool GenerateRegistrationCode(string requestCode, out string registrationCode, out string msg)
        {
            registrationCode = "";
            msg = "";

            // Base64解码
            msg = "Base64解码失败";
            if (!Base64Coder.FromBase64String(requestCode, out byte[] encryptData))
                return false;

            // RSA私钥解密 
            msg = "RSA解密失败";
            RSACryption rsa = new RSACryption();
            if (!rsa.Decrypt(RSAPRIVATEKEY, encryptData, out byte[] pack) || pack.Length < 5)
                return false;

            // 版本
            int version = BitConverter.ToInt32(pack, 0);
            if (version != VERSION)
            {
                msg = $"版本不匹配，申请码版本：{version}";
                return false;
            }

            // 完善授权信息
            RegistrationInfo registrationInfo = null;
            try
            {
                byte[] data = pack.Skip(4).ToArray();
                registrationInfo = BinarySerializer.GetObject(data) as RegistrationInfo;
                registrationInfo.ExpirationDate = DateTime.Now.AddYears(1).ToBinary();
            }
            catch
            {
                msg = "提取注册信息失败";
                return false;
            }

            // AES加密
            byte[] authorization = BinarySerializer.ObjectToBytes(registrationInfo);
            byte[] newPack = pack.Take(4).Concat(authorization).ToArray();
            AESCryption aes = new AESCryption();
            byte[] aesData = aes.Encrypt(AESKEY, newPack);

            // RSA私钥签名
            byte[] hashData = rsa.GetHash(aesData);
            byte[] signature = rsa.Signature(RSAPRIVATEKEY, hashData);

            // 组装签名和数据
            byte[] packAll = BitConverter.GetBytes(signature.Length).Concat(signature).Concat(aesData).ToArray();

            // Base64编码
            registrationCode = Convert.ToBase64String(packAll);

            return true;
        }

        #endregion
    }
}
