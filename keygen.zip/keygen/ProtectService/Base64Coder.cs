﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProtectService
{
    public class Base64Coder
    {
        public static string Base64Code(string Message)
        {
            byte[] bytes = Encoding.Default.GetBytes(Message);
            return Convert.ToBase64String(bytes);
        }

        public static string Base64Decode(string Message)
        {
            byte[] bytes = Convert.FromBase64String(Message);
            return Encoding.Default.GetString(bytes);
        }

        public static bool FromBase64String(string s, out byte[] data)
        {
            data = null;

            try
            {
                data = Convert.FromBase64String(s);
            }
            catch {}

            return data != null && data.Length > 0;
        }
    }
}
