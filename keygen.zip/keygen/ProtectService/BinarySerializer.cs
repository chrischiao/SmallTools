﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace ProtectService
{
    public class BinarySerializer
    {
        /// <summary>
        /// 将byte[]数组转换为Object
        /// </summary>
        /// <param name="originalBytes"></param>
        /// <returns></returns>
        public static object GetObject(byte[] bytes)
        {
            using (var stream = new MemoryStream(bytes))
            {
                stream.Position = 0;
                var formatter = new BinaryFormatter();
                return formatter.Deserialize(stream);
            }
        }

        /// <summary>
        /// 将object转换为byte[]数组
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public static byte[] ObjectToBytes(object model)
        {
            using (var stream = new MemoryStream())
            {
                var formatter = new BinaryFormatter();
                formatter.Serialize(stream, model);
                var bytes = stream.GetBuffer();
                stream.Close();
                return bytes;
            }
        }
    }
}
