﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProtectService
{
    [Serializable]
    public class RegistrationInfo
    {
        public string MAC { get; set; }

        public string MotherBoardId { get; set; }

        public long ExpirationDate { get; set; }

        //public string Company { get; set; }
    }
}
