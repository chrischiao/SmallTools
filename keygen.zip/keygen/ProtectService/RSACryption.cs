﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;

namespace ProtectService
{
    public class RSACryption
    {
        /// <summary>
        /// RSA 的密钥产生 产生私钥和公钥 
        /// </summary>
        /// <param name="xmlKeys"></param>
        /// <param name="xmlPublicKey"></param>
        public static void RSAKey(out string xmlKeys, out string xmlPublicKey)
        {
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
            xmlKeys = rsa.ToXmlString(true);
            xmlPublicKey = rsa.ToXmlString(false);
        }

        public byte[] Encrypt(string xmlPublicKey, byte[] data)
        {
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
            rsa.FromXmlString(xmlPublicKey);
            int keySize = rsa.KeySize / 8;
            int bufferSize = keySize - 11;

            var msInput = new System.IO.MemoryStream(data);
            var msOutput = new System.IO.MemoryStream();
            byte[] buffer = new byte[bufferSize];
            int readLen = msInput.Read(buffer, 0, bufferSize);
            while (readLen > 0)
            {
                byte[] dataToEnc = new byte[readLen];
                Array.Copy(buffer, 0, dataToEnc, 0, readLen);
                byte[] encData = rsa.Encrypt(dataToEnc, false);
                msOutput.Write(encData, 0, encData.Length);

                readLen = msInput.Read(buffer, 0, bufferSize);
            }

            byte[] result = msOutput.ToArray();
            msInput.Close();
            msOutput.Close();

            return result;

            #region 不使用流
            //int length = data.Length;
            //int blockLength = rsa.KeySize / 8 - 11;

            //if (length <= blockLength)
            //    return rsa.Encrypt(data, false);

            //// 分段加密
            //byte[] pack = null;
            //int count = length / blockLength;
            //for (int i = 0; i < count; i++)
            //{
            //    byte[] buffer = rsa.Encrypt(data.Skip(i*blockLength).Take(blockLength).ToArray(), false);
            //    AppendArray(ref pack, buffer);
            //}

            //if (length - count * blockLength > 0)
            //{
            //    byte[] buffer = rsa.Encrypt(data.Skip(count * blockLength).ToArray(), false);
            //    AppendArray(ref pack, buffer);
            //}

            //return pack;
            #endregion
        }

        public bool Decrypt(string xmlPrivateKey, byte[] encryptData, out byte[] originalData)
        {
            originalData = null;

            if (encryptData == null || encryptData.Length == 0 || string.IsNullOrEmpty(xmlPrivateKey))
                return false;

            try
            {
                RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
                rsa.FromXmlString(xmlPrivateKey);
                int keySize = rsa.KeySize / 8;

                var msInput = new System.IO.MemoryStream(encryptData);
                var msOutput = new System.IO.MemoryStream();
                byte[] buffer = new byte[keySize];
                int readLen = msInput.Read(buffer, 0, keySize);
                while (readLen > 0)
                {
                    byte[] dataToDec = new byte[readLen];
                    Array.Copy(buffer, 0, dataToDec, 0, readLen);
                    byte[] data = rsa.Decrypt(dataToDec, false);
                    msOutput.Write(data, 0, data.Length);

                    readLen = msInput.Read(buffer, 0, keySize);
                }

                originalData = msOutput.ToArray();
                msInput.Close();
                msOutput.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }

        private void AppendArray(ref byte[] source, byte[] buffer)
        {
            int originalLength = source == null ? 0 : source.Length;
            Array.Resize(ref source, originalLength + buffer.Length);
            Array.Copy(buffer, 0, source, originalLength, buffer.Length);
        }

        public byte[] GetHash(byte[] data)
        {
            HashAlgorithm md5 = HashAlgorithm.Create("MD5");
            byte[] hashData = md5.ComputeHash(data);
            return hashData;
        }

        public byte[] Signature(string xmlPrivateKey, byte[] hashbytes)
        {
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
            rsa.FromXmlString(xmlPrivateKey);
            RSAPKCS1SignatureFormatter rsaFormatter = new RSAPKCS1SignatureFormatter(rsa);
            rsaFormatter.SetHashAlgorithm("MD5");
            return rsaFormatter.CreateSignature(hashbytes);
        }

        public bool VerifySignature(string xmlPublicKey, byte[] hashbytes, byte[] signatureBytes)
        {
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
            rsa.FromXmlString(xmlPublicKey);
            RSAPKCS1SignatureDeformatter rsaDeformatter = new RSAPKCS1SignatureDeformatter(rsa);
            rsaDeformatter.SetHashAlgorithm("MD5");
            return rsaDeformatter.VerifySignature(hashbytes, signatureBytes);
        }
    }
}
