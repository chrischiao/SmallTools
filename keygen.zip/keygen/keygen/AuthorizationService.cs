﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ProtectService;

namespace keygen
{
    public class AuthorizationService
    {
        private const string AESKEY = "WNYz68HIePK3Es9CQQd4Zar4v0AI6wriXoociWxazMU=";
        private const string RSAPRIVATEKEY = "<RSAKeyValue><Modulus>3Mr/6vyQ6f6W4PbJ4UmrfmBYXWOXAbwov9GDyntv5TDYsdI+7Tx+kA/7dNhiCfFaRSRmV85vzsGAJEDkRlBg6mlhdaX89Tt0T4zpul42Vm0J5K3hBCK+zhfU/SmdCZtjH4geRoovD8+l4KUQ8z30wlcZFaEqhDR5CeCU5+8ZCEU=</Modulus><Exponent>AQAB</Exponent><P>+FLBKwADg7gy1y+Evj73ovKJE7+USGhxOUu399EOFmonA5oxd+uYp2oTj/SIbnp7VoENMjaiZYxXPmKjvMDb1w==</P><Q>455eYznRJO3iSa8N6wwfLOZx4+FVV41zhPKlBG27yqctdFv/+IDbyTC8u1icqBLRI5U6DzZJ6HT++taIHSSZQw==</Q><DP>nY176/llQXRkJW2Lzl0LJ4K0gCgkP9CsTcsB3STxyDzvpfR2AH0lbMr7wHFJAreJe7gDlGFfpghl7joNYxwGHw==</DP><DQ>FNFlPJoLIN+I9MhH85l2OHsTK45uacWMLTqsEQ2gQVas95l6fdX7RBlrCY9/NHgUHLcHSmDivZoFwBdi95djVQ==</DQ><InverseQ>SDw7Lx1ZYrwyIPzqJLTFYIqbYnFjSjJ4M9+yu8d+zBlBqhgGyV6jmxhXJWKwsEsa+jDMNAkUL0Ri/adOfRm8qg==</InverseQ><D>AlkiWaRwAh0UC7Z0NTIsYb6ykeOyQnF22Xtn9GpVqVFYrKN4ydsf2XZiDT8T49kuRZf6gqqOY9uI+lm6U8kdDrwaWsAL8je9e7+Uasqwyc9pKsMmcWG8s0ahpHh3DSR1JDy6wGayvCZJntXlkDa5EfbUxc8c3BW2ZjG8dwaess0=</D></RSAKeyValue>";

        public const int VERSION = 1;

        /// <summary>
        /// 根据申请码生成注册码
        /// </summary>
        public static bool GenerateRegistrationCode(string requestCode, out string registrationCode, out string msg)
        {
            registrationCode = "";
            msg = "";

            // Base64解码
            msg = "Base64解码失败";
            if (!Base64Coder.FromBase64String(requestCode, out byte[] encryptData))
                return false;

            // RSA私钥解密 
            msg = "RSA解密失败";
            RSACryption rsa = new RSACryption();
            if (!rsa.Decrypt(RSAPRIVATEKEY, encryptData, out byte[] pack) || pack.Length < 5)
                return false;

            // 版本
            int version = BitConverter.ToInt32(pack, 0);
            if (version != VERSION)
            {
                msg = $"版本不匹配，申请码版本：{version}";
                return false;
            }

            // 完善授权信息
            RegistrationInfo registrationInfo = null;
            try
            {
                byte[] data = pack.Skip(4).ToArray();
                registrationInfo = BinarySerializer.GetObject(data) as RegistrationInfo;
                registrationInfo.ExpirationDate = DateTime.Now.AddYears(1).ToBinary();
            }
            catch
            {
                msg = "提取注册信息失败";
                return false;
            }

            // AES加密
            byte[] authorization = BinarySerializer.ObjectToBytes(registrationInfo);
            byte[] newPack = pack.Take(4).Concat(authorization).ToArray();
            AESCryption aes = new AESCryption();
            byte[] aesData = aes.Encrypt(AESKEY, newPack);

            // RSA私钥签名
            byte[] hashData = rsa.GetHash(aesData);
            byte[] signature = rsa.Signature(RSAPRIVATEKEY, hashData);

            // 组装签名和数据
            byte[] packAll = BitConverter.GetBytes(signature.Length).Concat(signature).Concat(aesData).ToArray();

            // Base64编码
            registrationCode = Convert.ToBase64String(packAll);

            return true;
        }
    }
}
