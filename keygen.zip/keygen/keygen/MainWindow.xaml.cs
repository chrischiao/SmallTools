﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace keygen
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Registe_Click(object sender, RoutedEventArgs e)
        {
            string requestCode = this.tbRequest.Text;
            if (string.IsNullOrEmpty(requestCode))
                return;

            string registrationCode;
            string msg;
            if (AuthorizationService.GenerateRegistrationCode(requestCode, out registrationCode, out msg))
            {
                this.tbRegister.Text = registrationCode;
                this.btnCopy.IsEnabled = true;
            }
            else
                MessageBox.Show(msg);
        }

        private void CopyButton_Click(object sender, RoutedEventArgs e)
        {
            Clipboard.SetText(this.tbRegister.Text);
        }

        private void PasteButton_Click(object sender, RoutedEventArgs e)
        {
            this.tbRequest.Text = Clipboard.GetText();
        }
    }
}
