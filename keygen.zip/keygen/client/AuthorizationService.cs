﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Management;
using ProtectService;

namespace client
{
    public class AuthorizationService
    {
        private const string AESKEY = "WNYz68HIePK3Es9CQQd4Zar4v0AI6wriXoociWxazMU=";
        private const string RSAPUBLICKEY = "<RSAKeyValue><Modulus>3Mr/6vyQ6f6W4PbJ4UmrfmBYXWOXAbwov9GDyntv5TDYsdI+7Tx+kA/7dNhiCfFaRSRmV85vzsGAJEDkRlBg6mlhdaX89Tt0T4zpul42Vm0J5K3hBCK+zhfU/SmdCZtjH4geRoovD8+l4KUQ8z30wlcZFaEqhDR5CeCU5+8ZCEU=</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>";

        private const int VERSION = 1;

        /// <summary>
        /// 生成申请码
        /// </summary>
        public static string GenerateRequestCode()
        {
            // 版本信息
            byte[] version = BitConverter.GetBytes(VERSION);

            // 注册信息
            var registrationInfo = new RegistrationInfo
            {
                MAC = GetMacAddress(),
                MotherBoardId = GetMotherBoardID(),
            };
            byte[] data = BinarySerializer.ObjectToBytes(registrationInfo);
            byte[] pack = version.Concat(data).ToArray();

            // RSA公钥加密
            RSACryption rsa = new RSACryption();
            byte[] encryptBytes = rsa.Encrypt(RSAPUBLICKEY, pack);

            // Base64编码
            return Convert.ToBase64String(encryptBytes);
        }

        /// <summary>
        /// 验证授权
        /// </summary>
        public static bool VerifyAuthorization(string registrationCode, out string msg)
        {
            msg = "解码失败";
            if (!Base64Coder.FromBase64String(registrationCode, out byte[] fullData) || fullData.Length < 5)
                return false;

            int signatureLength = BitConverter.ToInt32(fullData, 0);
            if (fullData.Length < 5 + signatureLength)
                return false;

            byte[] signature = fullData.Skip(4).Take(signatureLength).ToArray();
            byte[] encryptData = fullData.Skip(4 + signatureLength).ToArray();

            // RSA公钥验证签名
            msg = "签名错误";
            RSACryption rsa = new RSACryption();
            byte[] hashData = rsa.GetHash(encryptData);
            if (!rsa.VerifySignature(RSAPUBLICKEY, hashData, signature))
                return false;

            // AES解密
            msg = "解密失败";
            AESCryption aes = new AESCryption();
            if (!aes.Decrypt(encryptData, AESKEY, out byte[] pack) || pack.Length < 5)
                return false;

            // 判断版本
            msg = "软件版本不匹配";
            int version = BitConverter.ToInt32(pack, 0);
            if (version != VERSION)
                return false;

            // 验证注册信息
            msg = "提取注册信息失败";
            try
            {
                byte[] data = pack.Skip(4).ToArray();
                RegistrationInfo registrationInfo = BinarySerializer.GetObject(data) as RegistrationInfo;
                return IslegalRegistration(registrationInfo, out msg);
            }
            catch
            {
                return false;
            }
        }

        public static bool IslegalRegistration(RegistrationInfo registrationInfo, out string msg)
        {
            msg = "已到期";
            DateTime expirationDate = DateTime.FromBinary(registrationInfo.ExpirationDate);
            if (expirationDate < DateTime.Now)
                return false;

            msg = "注册信息与本机信息不匹配";
            string mac = GetMacAddress();
            if (!string.Equals(mac, registrationInfo.MAC))
                return false;

            string boardId = GetMotherBoardID();
            if (!string.Equals(boardId, registrationInfo.MotherBoardId))
                return false;

            msg = "";
            return true;
        }

        public static void SaveAuthorization(string registrationCode)
        {
            if (!Base64Coder.FromBase64String(registrationCode, out byte[] data))
                return;

            string filePath = GetAuthorizationPath();
            if (File.Exists(filePath))
                File.Delete(filePath);

            using (FileStream fs = new FileStream(filePath, FileMode.Create))
            { 
                // 保存成文本文件
                //using (StreamWriter sw = new StreamWriter(fs))
                //{
                //    sw.Write(registrationCode);
                //    sw.Flush();
                //    sw.Close();
                //    fs.Close();
                //}

                // 保存成二进制文件
                fs.Seek(0, SeekOrigin.Begin);
                fs.Write(data, 0, data.Length);
                fs.Flush();
                fs.Close();
            }
        }

        public static bool ReadAuthorization()
        {
            string filePath = GetAuthorizationPath();
            if (!File.Exists(filePath))
                return false;

            string registrationCode = string.Empty;
            using (FileStream fs = new FileStream(filePath, FileMode.Open))
            {
                // 读文本文件
                //using (StreamReader rw = new StreamReader(fs))
                //{
                //    registrationCode = rw.ReadToEnd();
                //    rw.Close();
                //    fs.Close();
                //}

                // 读二进制文件
                byte[] bytes = new byte[fs.Length];
                int numBytesToRead = (int)fs.Length;
                int numBytesRead = 0;
                while (numBytesToRead > 0)
                {
                    // Read may return anything from 0 to numBytesToRead.
                    int n = fs.Read(bytes, numBytesRead, numBytesToRead);
                    // Break when the end of the file is reached.
                    if (n == 0)
                        break;
                    numBytesRead += n;
                    numBytesToRead -= n;
                }
                registrationCode = Convert.ToBase64String(bytes);
            }

            return VerifyAuthorization(registrationCode, out string msg);
        }

        private static string GetAuthorizationPath()
        {
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Fashion.LK");
        }

        public static string GetMacAddress()
        {
            try
            {
                string mac = string.Empty;
                ManagementClass mc = new ManagementClass("Win32_NetworkAdapterConfiguration");
                ManagementObjectCollection moc = mc.GetInstances();
                foreach (ManagementObject mo in moc)
                {
                    if ((bool)mo["IPEnabled"] == true)
                    {
                        mac = mo["MacAddress"].ToString();
                    }
                }
                moc = null;
                mc = null;
                return mac;
            }
            catch
            {
                return "unknown";
            }
        }

        public static string GetMotherBoardID()
        {
            try
            {
                ManagementClass mc = new ManagementClass("Win32_BaseBoard");
                ManagementObjectCollection moc = mc.GetInstances();
                string id = null;
                foreach (ManagementObject mo in moc)
                {
                    id = mo.Properties["SerialNumber"].Value.ToString();
                    break;
                }
                return id;
            }
            catch
            {
                return "unknown";
            }
        }
    }
}
