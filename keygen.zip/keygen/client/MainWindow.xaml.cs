﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace client
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
   
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (AuthorizationService.ReadAuthorization())
            {
                this.tbCode.IsEnabled = false;
                this.tbCode.Text = "已授权";
                this.btnCopy.IsEnabled = false;
                this.btnNext.IsEnabled = false;
            }
            else
            {
                string requestCode = AuthorizationService.GenerateRequestCode();
                this.tbCode.Text = requestCode;
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void NextButton_Click(object sender, RoutedEventArgs e)
        {
            this.tbCode.Text = "";
            this.btnCopy.Visibility = Visibility.Collapsed;
            this.btnNext.Visibility = Visibility.Collapsed;
            this.btnRegister.Visibility = Visibility.Visible;
            this.btnPaste.Visibility = Visibility.Visible;
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            string registerCode = this.tbCode.Text;
            if (string.IsNullOrEmpty(registerCode))
                return;

            if (AuthorizationService.VerifyAuthorization(registerCode, out string msg))
            {
                AuthorizationService.SaveAuthorization(registerCode);

                MessageBox.Show("注册成功");
                this.Close();
            }
            else
                MessageBox.Show("注册码错误");
        }

        private void CopyButton_Click(object sender, RoutedEventArgs e)
        {
            Clipboard.SetText(this.tbCode.Text);
        }

        private void PasteButton_Click(object sender, RoutedEventArgs e)
        {
            this.tbCode.Text = Clipboard.GetText();
        }
    }
}
